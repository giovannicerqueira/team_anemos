double integral, previous, output = 0;

double pid(double error, double dt, double previous, double kp, double ki, double kd)
{
  // Adjust simply proportional to error
  double proportional = error;

  // Compute the integral with a Riemann Approximation
  // Area = b * h = error * time_interval
  integral += error * dt;

  // Compute the derivative as the slope between the 
  // current error and the previous error term.
  double derivative = (error - previous) / dt;
  previous = error;

  // Scale each P, I, and D term by its weight
  // THIS WEIGHTS WILL NEED TO BE TUNED!
  double output = (kp * proportional) + (ki * integral) + (kd * derivative);

  
  return output;
}