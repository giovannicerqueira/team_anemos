void PWM_INIT(int fanPin) {
  pinMode(fanPin, OUTPUT);

  int pwmGoal = 0;
  int inverted_pwm = (100 - pwmGoal) * 255 / 100;
  analogWrite(fanPin, inverted_pwm);  // Set the LED brightness using PWM
  delay(5000);
}

void PWM_SET(int fanPin, double pwmGoal) {
  double inverted_pwm = (100 - pwmGoal) * 255 / 100;
  analogWrite(fanPin, inverted_pwm);  // Set the LED brightness using PWM
  // May want to tweak this delay if we find weird things happening during operation
  delay(100);
  //Serial.println("XXX State");
}